"""8BitDo joystick -> USB serial -> Arduino pan/tilt servos."""
from __future__ import annotations

import argparse
import sys
import time

import pygame
import serial
from serial.tools import list_ports

# ---- Hardware/controller settings: edit these for your setup ----
PORT = "COM3"                 # Windows Device Manager > Ports (COM & LPT)
BAUD = 115200                 # Must match the Arduino sketch
PAN_AXIS = 0                  # Left stick horizontal axis (verify with --monitor)
TILT_AXIS = 1                 # Left stick vertical axis (verify with --monitor)
X_BUTTON = 2                  # X button in common XInput mapping; confirm with --monitor
Y_BUTTON = 3                  # Y button in common XInput mapping; confirm with --monitor
PAN_INVERT = False            # True reverses direction
TILT_INVERT = True            # Most controllers report up as negative
DEADZONE = 0.10               # Ignore the center 10% of stick travel
PAN_MIN, PAN_MAX = 15, 165    # Mechanical safe limits; adjust for your mount
TILT_MIN, TILT_MAX = 20, 160
SEND_HZ = 30
# ---------------------------------------------------------------


def angle_from_axis(value: float, low: int, high: int, invert: bool) -> int:
    value = 0.0 if abs(value) < DEADZONE else value
    value = max(-1.0, min(1.0, value))
    if invert:
        value = -value
    # Center at half range; full stick travel reaches the configured limits.
    return round((low + high) / 2 + value * (high - low) / 2)


def ports() -> None:
    found = list(list_ports.comports())
    if not found:
        print("No serial ports found. Connect the Arduino by USB.")
    for port in found:
        print(f"{port.device}: {port.description}")


def run(monitor: bool, window: bool = False) -> int:
    pygame.init()
    pygame.joystick.init()
    if pygame.joystick.get_count() == 0:
        print("No game controller detected. Pair the 8BitDo over Bluetooth, then retry.")
        pygame.quit()
        return 1

    stick = pygame.joystick.Joystick(0)
    stick.init()
    print(f"Controller: {stick.get_name()} | axes: {stick.get_numaxes()}")
    if stick.get_numaxes() <= max(PAN_AXIS, TILT_AXIS):
        print("Configured axis number is not present. Run --monitor and update PAN_AXIS/TILT_AXIS.")
        pygame.quit()
        return 1

    link = None
    if not monitor:
        try:
            # Arduino resets when serial opens. Wait for its bootloader to finish.
            link = serial.Serial(PORT, BAUD, timeout=0.1, write_timeout=0.2)
            time.sleep(2)
            link.reset_input_buffer()
            print(f"Connected to Arduino on {PORT} at {BAUD} baud. Press Ctrl+C to stop.")
        except serial.SerialException as exc:
            print(f"Could not open {PORT}: {exc}\nRun python controller.py --ports and set PORT.")
            pygame.quit()
            return 1
    else:
        print("Axis monitor: move the left stick; Ctrl+C to stop.")

    if window:
        if monitor or link is None:
            print("The live window needs the Arduino serial connection. Run without --monitor.")
            pygame.quit()
            return 1
        return run_window(stick, link)

    clock = pygame.time.Clock()
    mode_active = False
    try:
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return 0
                if event.type == pygame.JOYDEVICEREMOVED:
                    print("Controller disconnected; stopping.")
                    return 1
                if event.type == pygame.JOYBUTTONDOWN and event.button == Y_BUTTON:
                    mode_active = not mode_active
                    print("Control mode" if mode_active else "Standby mode")
                elif event.type == pygame.JOYBUTTONDOWN and event.button == X_BUTTON:
                    if mode_active and not monitor and link is not None:
                        link.write(b"X\n")
                        print("X button -> Motor 3 command sent")
            pygame.event.pump()
            pan_raw = stick.get_axis(PAN_AXIS)
            tilt_raw = stick.get_axis(TILT_AXIS)
            pan = angle_from_axis(pan_raw, PAN_MIN, PAN_MAX, PAN_INVERT)
            tilt = angle_from_axis(tilt_raw, TILT_MIN, TILT_MAX, TILT_INVERT)
            if monitor:
                buttons = [i for i in range(stick.get_numbuttons()) if stick.get_button(i)]
                print(f"axes[{PAN_AXIS}]={pan_raw:+.3f} axes[{TILT_AXIS}]={tilt_raw:+.3f} -> pan={pan} tilt={tilt} buttons={buttons}   ", end="\r")
            elif link is not None and mode_active:
                link.write(f"P,{pan},{tilt}\n".encode("ascii"))
            clock.tick(SEND_HZ)
    except KeyboardInterrupt:
        print("\nStopped.")
        return 0
    except (serial.SerialException, OSError) as exc:
        print(f"Serial communication failed: {exc}")
        return 1
    finally:
        if link is not None and link.is_open:
            link.close()
        pygame.quit()


def run_window(stick, link) -> int:
    """Show local joystick values and Arduino acknowledgements in a Tk window."""
    import tkinter as tk
    from tkinter.scrolledtext import ScrolledText

    root = tk.Tk()
    root.title("컨트롤러 / Arduino 실시간 확인")
    root.geometry("620x470")
    root.minsize(520, 400)

    def value_label(parent, text, size=15):
        return tk.Label(parent, text=text, font=("맑은 고딕", size), anchor="w")

    title = value_label(root, "컨트롤러 입력 및 Arduino 수신 확인", 17)
    title.pack(fill="x", padx=16, pady=(14, 8))
    mode_text = value_label(root, "대기 모드 (Y를 눌러 동작 모드로 전환)", 14)
    mode_text.config(fg="#a35a00")
    mode_text.pack(fill="x", padx=20, pady=3)
    pan_text = value_label(root, "팬: --°   (축 값 --)", 16)
    tilt_text = value_label(root, "틸트: --°   (축 값 --)", 16)
    pan_text.pack(fill="x", padx=20, pady=3)
    tilt_text.pack(fill="x", padx=20, pady=3)
    x_text = value_label(root, "X 버튼: 대기 중 | 모터3: Arduino 응답 대기", 12)
    x_text.pack(fill="x", padx=20, pady=(8, 3))
    buttons_text = value_label(root, f"누르고 있는 버튼 번호: 없음  |  X={X_BUTTON}, Y={Y_BUTTON}", 10)
    buttons_text.pack(fill="x", padx=20, pady=2)
    ack_text = value_label(root, "Arduino 응답: 아직 수신되지 않음", 11)
    ack_text.pack(fill="x", padx=20, pady=3)
    tk.Label(root, text="이벤트 로그", font=("맑은 고딕", 11, "bold"), anchor="w").pack(fill="x", padx=16, pady=(10, 2))
    log = ScrolledText(root, height=12, state="disabled", font=("Consolas", 10))
    log.pack(fill="both", expand=True, padx=16, pady=(0, 8))
    tk.Label(root, text="종료하려면 이 창을 닫으세요. Arduino IDE 시리얼 모니터는 닫아 두세요.",
             font=("맑은 고딕", 9), anchor="w").pack(fill="x", padx=16, pady=(0, 10))

    receive_buffer = bytearray()
    last_ack = ""
    pan_ack_count = 0
    last_x_text = "X 버튼: 대기 중"
    mode_active = False
    active = True

    def add_log(message: str) -> None:
        log.configure(state="normal")
        log.insert("end", time.strftime("%H:%M:%S ") + message + "\n")
        log.see("end")
        log.configure(state="disabled")

    add_log(f"컨트롤러: {stick.get_name()} / Arduino 포트: {PORT}")
    add_log(f"대기 모드입니다. Y 버튼(인덱스 {Y_BUTTON})을 눌러야 값을 전송합니다.")

    def close_window() -> None:
        nonlocal active
        active = False
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", close_window)

    def tick() -> None:
        nonlocal last_ack, pan_ack_count, last_x_text, mode_active, receive_buffer
        if not active:
            return
        for event in pygame.event.get():
            if event.type == pygame.QUIT or event.type == pygame.JOYDEVICEREMOVED:
                close_window()
                return
            if event.type == pygame.JOYBUTTONDOWN and event.button == Y_BUTTON:
                mode_active = not mode_active
                mode_text.config(text="동작 모드 (명령 전송 중)" if mode_active else "대기 모드 (명령 전송 안 함)",
                                 fg="#167d32" if mode_active else "#a35a00")
                add_log("Y 버튼 입력 → " + ("동작 모드: Arduino로 값 전송 시작" if mode_active else "대기 모드: Arduino 전송 중지"))
            elif event.type == pygame.JOYBUTTONDOWN and event.button == X_BUTTON:
                if mode_active:
                    link.write(b"X\n")
                    last_x_text = f"X 버튼: 입력 감지 (버튼 {event.button}) | Arduino 응답 대기 중"
                    add_log(f"X 버튼(인덱스 {event.button}) 입력 → Motor 3 회전 명령 전송")
                else:
                    last_x_text = f"X 버튼: 대기 모드라 무시됨 (버튼 {event.button})"
                    add_log("대기 모드에서 X 입력: Arduino로 보내지 않음")
                x_text.config(text=last_x_text)

        pygame.event.pump()
        pan_raw = stick.get_axis(PAN_AXIS)
        tilt_raw = stick.get_axis(TILT_AXIS)
        pan = angle_from_axis(pan_raw, PAN_MIN, PAN_MAX, PAN_INVERT)
        tilt = angle_from_axis(tilt_raw, TILT_MIN, TILT_MAX, TILT_INVERT)
        pan_text.config(text=f"팬: {pan}°   (축 {PAN_AXIS}: {pan_raw:+.3f})")
        tilt_text.config(text=f"틸트: {tilt}°   (축 {TILT_AXIS}: {tilt_raw:+.3f})")
        pressed = [i for i in range(stick.get_numbuttons()) if stick.get_button(i)]
        buttons_text.config(text=f"누르고 있는 버튼 번호: {pressed or '없음'}  |  X={X_BUTTON}, Y={Y_BUTTON}")
        if mode_active:
            link.write(f"P,{pan},{tilt}\n".encode("ascii"))

        waiting = link.in_waiting
        if waiting:
            receive_buffer.extend(link.read(waiting))
            while b"\n" in receive_buffer:
                raw_line, _, rest = receive_buffer.partition(b"\n")
                receive_buffer = bytearray(rest)
                response = raw_line.decode("ascii", errors="replace").strip()
                if response.startswith("ACK,P,"):
                    last_ack = response
                    pan_ack_count += 1
                    ack_text.config(text=f"Arduino 응답: {last_ack}  (수신 {pan_ack_count}회)")
                elif response.startswith("ACK,X,"):
                    last_ack = response
                    x_text.config(text=f"X 버튼: Arduino 수신 확인 | {response}")
                    add_log(f"Arduino 응답 수신: {response}")
        root.after(33, tick)

    try:
        root.after(0, tick)
        root.mainloop()
        return 0
    finally:
        if link.is_open:
            link.close()
        pygame.quit()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ports", action="store_true", help="list available serial ports and exit")
    parser.add_argument("--monitor", action="store_true", help="show joystick axes without sending serial data")
    parser.add_argument("--window", action="store_true", help="open a live window showing joystick values and Arduino acknowledgements")
    parser.add_argument("--console", action="store_true", help="use the old terminal-only mode instead of the live window")
    args = parser.parse_args()
    if args.ports:
        ports()
        return 0
    use_window = not args.monitor and (args.window or not args.console)
    return run(args.monitor, use_window)


if __name__ == "__main__":
    sys.exit(main())
