#include <Servo.h>
#include <string.h>
#include <stdlib.h>

// Arduino Uno R4 example. Signal pins can be changed for your board.
const byte PAN_PIN = 9;
const byte TILT_PIN = 10;
const byte STATUS_LED_PIN = LED_BUILTIN;
const int PAN_MIN = 15, PAN_MAX = 165;
const int TILT_MIN = 20, TILT_MAX = 160;
const int PAN_HOME = 90, TILT_HOME = 90;
const unsigned long COMMAND_TIMEOUT_MS = 1500;
const unsigned long LED_PULSE_MS = 150;

Servo panServo;
Servo tiltServo;
char lineBuffer[40];
byte lineLength = 0;
unsigned long lastCommandMs = 0;
bool hasCommand = false;
int lastPan = PAN_HOME, lastTilt = TILT_HOME;
unsigned long ledOffAt = 0;

void setup() {
  Serial.begin(115200);
  panServo.attach(PAN_PIN);
  tiltServo.attach(TILT_PIN);
  pinMode(STATUS_LED_PIN, OUTPUT);
  panServo.write(PAN_HOME);
  tiltServo.write(TILT_HOME);
  digitalWrite(STATUS_LED_PIN, LOW);
  lastCommandMs = millis();
}

void processLine(char *line) {
  if (line[0] == '\0') return;
  if (strcmp(line, "X") == 0) {
    // Motor 3 is a stepper, but its driver and steps-per-revolution are not
    // known yet. Acknowledge reception now; configure the driver before moving it.
    Serial.println("ACK,X,RECEIVED,DRIVER_NOT_CONFIGURED");
    return;
  }
  // Protocol: P,<pan degrees>,<tilt degrees>\n  e.g. P,90,90
  if (line[0] != 'P' || line[1] != ',') return;
  char *comma = strchr(line + 2, ',');
  if (comma == nullptr) return;
  *comma = '\0';
  char *endPan;
  char *endTilt;
  long pan = strtol(line + 2, &endPan, 10);
  long tilt = strtol(comma + 1, &endTilt, 10);
  if (*endPan != '\0' || *endTilt != '\0') return;

  pan = constrain(pan, PAN_MIN, PAN_MAX);
  tilt = constrain(tilt, TILT_MIN, TILT_MAX);
  if (pan != lastPan || tilt != lastTilt) {
    digitalWrite(STATUS_LED_PIN, HIGH);
    ledOffAt = millis() + LED_PULSE_MS;
  }
  lastPan = (int)pan;
  lastTilt = (int)tilt;
  panServo.write((int)pan);
  tiltServo.write((int)tilt);
  Serial.print("ACK,P,");
  Serial.print(pan);
  Serial.print(',');
  Serial.println(tilt);
  hasCommand = true;
  lastCommandMs = millis();
}

void loop() {
  if (digitalRead(STATUS_LED_PIN) == HIGH && (long)(millis() - ledOffAt) >= 0) {
    digitalWrite(STATUS_LED_PIN, LOW);
  }
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\n') {
      lineBuffer[lineLength] = '\0';
      processLine(lineBuffer);
      lineLength = 0;
    } else if (c != '\r') {
      if (lineLength < sizeof(lineBuffer) - 1) lineBuffer[lineLength++] = c;
      else lineLength = 0;  // discard an overlong/corrupt line
    }
  }

  // If the PC/controller stops sending, return to the neutral position.
  if (hasCommand && millis() - lastCommandMs > COMMAND_TIMEOUT_MS) {
    panServo.write(PAN_HOME);
    tiltServo.write(TILT_HOME);
    hasCommand = false;
  }
}
