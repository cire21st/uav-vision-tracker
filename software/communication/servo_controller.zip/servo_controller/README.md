# 8BitDo → Arduino Pan/Tilt Servo Controller

VS Code project: Python reads the left stick and face buttons; Arduino drives the pan/tilt servos. Press Y to switch between standby and control modes. Arduino's built-in LED briefly lights whenever a pan/tilt angle changes. Motor 3 is a stepper; its driver-specific one-turn setup is pending identification of the stepper driver.

## Project contents

- `controller.py` — Bluetooth controller input and serial sender
- `arduino/pan_tilt_servo/pan_tilt_servo.ino` — Arduino receiver and servo control
- `requirements.txt` — Python packages

## Wiring (Uno/Nano example)

| Servo lead | Connect to |
| --- | --- |
| Pan signal (usually yellow/orange/white) | Arduino D9 |
| Tilt signal | Arduino D10 |
| Both servo grounds (brown/black) | External supply negative **and** Arduino GND |
| Both servo power (red) | Regulated external 5–6 V supply positive, sized for the servos |

Connect the external supply negative to an Arduino GND so the signal has a shared reference. Plug the Arduino into the laptop by USB for serial data. Do **not** power servos from the Arduino 5 V pin or laptop USB; multiple servos can draw more current than either can safely provide. Check each servo's voltage/current rating and supply polarity. Disconnect power while wiring. The built-in LED needs no external wiring. Motor 3's stepper driver wiring cannot be specified until its driver model is known.

## Setup

1. Pair the 8BitDo Ultimate 2 with Windows over Bluetooth. Use its XInput mode if available; close games or other programs that may capture the controller.
2. Open this folder in VS Code. In its terminal, create and activate a virtual environment, then install packages:

   ```powershell
   py -3 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```

   Choose `.venv` using **Python: Select Interpreter** in VS Code. The prior conversation reported Python 3.15.2 and a successful `pygame-ce` install; these instructions use `pygame-ce` (imported as `pygame`) so it avoids building the original `pygame` package. If your `py -3` does not resolve to an interpreter supported by the installed pygame-ce wheel, use a Python version with a published Windows wheel (for example Python 3.13) and recreate the environment.
3. Open the `.ino` file in Arduino IDE (or use the Arduino extension), select the correct board and USB port, and upload. Close Arduino Serial Monitor before starting Python because only one program can own the COM port at a time.
4. Find the Arduino port in Windows Device Manager → **Ports (COM & LPT)**, or run:

   ```powershell
   python controller.py --ports
   ```

5. Edit the settings near the top of `controller.py`: set `PORT` (for example `COM5`), and check `PAN_AXIS`/`TILT_AXIS` with the monitor. Defaults are COM3, axes 0/1, 115200 baud.
6. With servos disconnected or safely unloaded, verify the controller axes and button mapping:

   ```powershell
   python controller.py --monitor
   ```

   Move the left stick. At center, both values should be near 0; check which axes change. The live window shows currently pressed button numbers; defaults are X=2 and Y=3 for common XInput mappings. If your controller reports different values, update `X_BUTTON` and `Y_BUTTON`. Update axis numbers if needed. Flip `PAN_INVERT` or `TILT_INVERT` if a direction is reversed. The vertical axis is inverted by default because up is commonly negative.
7. Start the live window:

   ```powershell
   python controller.py
   ```

   The program starts in standby and sends no pan/tilt values. Press Y to enter control mode; press Y again to return to standby. Only while control mode is active, pan/tilt values are sent and X sends a Motor 3 command. The window shows local inputs and Arduino ACK responses. Motor 3 currently only acknowledges X; it will not turn until its driver type and steps-per-revolution are configured. Close the window to stop. Arduino returns pan/tilt to 90° if commands stop for 1.5 seconds.

## Calibration and safe limits

- `DEADZONE` ignores small stick drift around center. Try 0.08–0.15; increase only enough to prevent unwanted movement.
- `PAN_MIN`/`PAN_MAX` and `TILT_MIN`/`TILT_MAX` define travel endpoints. The sketch applies matching limits as a second guard. Start conservatively (for example 60–120°), test without a load, then widen in small steps. Make matching changes in both files.
- Standard servo horns may not be mechanically centered at 90°. Remove the horn, command 90°, then refit the horn at the desired neutral direction.
- If a servo buzzes, heats, hits a stop, or the mount binds, disconnect power and narrow its angle range. Servo.write degrees are approximate; actual travel varies by model.

## Serial protocol

Python sends one newline-terminated ASCII line at 30 Hz while control mode is active: `P,90,90\n` (pan, tilt degrees). An X press sends `X\n` (Motor 3 command). Y mode changes are handled locally by Python and do not move or command the Arduino. Both sides use 115200 baud. Arduino replies with `ACK,P,...` and `ACK,X,...`; this confirms that the board parsed the command. Motor 3 currently reports receipt only and will not move until its stepper driver and steps-per-revolution are configured.

## Troubleshooting

- **No controller detected:** confirm Windows Bluetooth says Connected, switch the controller to XInput mode if available, reconnect it, then run `--monitor`. Try disconnecting other gamepads.
- **Wrong axes or no response:** use `--monitor`; some controller modes expose different axis numbering. Edit `PAN_AXIS` and `TILT_AXIS` accordingly. The monitor also reveals whether stick center drifts.
- **Could not open COM port:** run `--ports`, update `PORT`, close Arduino Serial Monitor and other serial apps, and reconnect the USB cable. A charge-only cable will not work.
- **Arduino does not move:** confirm the sketch is uploaded, baud rates match, signal pins match, servo supply is on, and grounds are common. Try one servo and verify its model's wiring.
- **Jitter, reset, or buzzing:** use a separate regulated supply with enough current, common ground, and shorter/secure wiring. Reduce servo mechanical load and narrow travel limits.
- **`ModuleNotFoundError`:** activate `.venv`, select that interpreter in VS Code, and run `python -m pip install -r requirements.txt` there.

## Safety

Keep hands clear of linkages. Test the mechanism without a load first, keep the motion range small until direction and endpoints are verified, and have an easy way to cut servo power. A USB serial timeout returns to neutral, but it cannot guarantee a safe position for every mechanism. Do not connect an unknown servo supply voltage or reverse polarity.
